"""Static smoke tests, no AWS calls."""
import ast, json, pathlib
r=pathlib.Path(__file__).resolve().parents[1]
ast.parse((r/'lambda/handler.py').read_text())
ast.parse((r/'infra/generate.py').read_text())
w=json.loads((r/'infra/workflow.asl.json').read_text())
d=json.loads((r/'infra/ssm-document.json').read_text())
assert w['States']['Process']['MaxConcurrency']==10
assert w['States']['Process']['ItemProcessor']['States']['Wait']['Seconds']==15
assert d['parameters']['SecretArn']['type']=='String'
assert 'AWSPENDING' in (r/'ssm/rotate.ps1').read_text()
assert 'ROTATION_VERIFIED' in (r/'ssm/rotate.ps1').read_text()
assert 'secret.password' not in (r/'lambda/handler.py').read_text()
print('Static smoke tests passed')

# Check new role-name design and 20-character password default.
import os, importlib.util, collections
os.environ.update({
    'AWS_EC2_METADATA_DISABLED':'true', 'AWS_ACCESS_KEY_ID':'unit-test',
    'AWS_SECRET_ACCESS_KEY':'unit-test', 'AWS_DEFAULT_REGION':'ap-southeast-2',
    'CENTRAL_ACCOUNT_ID':'999999999999','TARGET_ACCOUNT_IDS':'111111111111,222222222222',
    'REPORT_BUCKET':'dummy-report-bucket',
    'SECRETS_KMS_KEY_ARN':'arn:aws:kms:ap-southeast-2:999999999999:key/dummy',
})
mod=importlib.util.spec_from_file_location('rotate_handler',r/'lambda/handler.py')
h=importlib.util.module_from_spec(mod);mod.loader.exec_module(h)
assert h.LEN==20
assert all(len(h.create_password()) == 20 for _ in range(200))
assert 'INSTANCE_ROLE' not in (r/'infra/central.yaml').read_text()
assert 'InstanceRoleNames:' in (r/'infra/target.yaml').read_text()
assert 'iam:GetInstanceProfile' in (r/'infra/target.yaml').read_text()
assert 'PASSWORD_LENGTH: \'20\'' in (r/'infra/central.yaml').read_text()

class Paginator:
    def __init__(self,pages):self.pages=pages
    def paginate(self,**kwargs):return iter(self.pages)
class Ec2:
    def get_paginator(self,name):
        assert name=='describe_instances'
        return Paginator([{'Reservations':[{'Instances':[
            {'InstanceId':'i-aaa', 'Tags':[{'Key':'PasswordRotation','Value':'enabled'}],
             'IamInstanceProfile':{'Arn':'arn:aws:iam::111111111111:instance-profile/Prod/AppProfile'}},
            {'InstanceId':'i-bbb', 'Tags':[{'Key':'PasswordRotation','Value':'enabled'}],
             'IamInstanceProfile':{'Arn':'arn:aws:iam::111111111111:instance-profile/DbProfile'}}]}]}])
class Ssm:
    def get_paginator(self,name):return Paginator([{'InstanceInformationList':[
        {'InstanceId':'i-aaa','PingStatus':'Online'},
        {'InstanceId':'i-bbb','PingStatus':'Online'}]}])
class Iam:
    def get_instance_profile(self,InstanceProfileName):
        role = {'AppProfile':'RoleABC','DbProfile':'DatabaseServerRole'}[InstanceProfileName]
        return {'InstanceProfile':{'Roles':[{'Arn':'arn:aws:iam::111111111111:role/Prod/'+role}]}}
old_assume,old_accounts=h.assume,h.ACCOUNTS
h.ACCOUNTS=['111111111111']
h.assume=lambda account,service:{'ec2':Ec2(),'ssm':Ssm(),'iam':Iam()}[service]
rows=h.discover({'dry_run':True, 'instance_ids':['i-aaa','i-bbb']})['items']
assert len(rows)==2
assert rows[0]['instance_role_arn'] != rows[1]['instance_role_arn']
assert all(row['ssm_online'] for row in rows)
h.assume,h.ACCOUNTS=old_assume,old_accounts
print('Role resolution and 20-character generation tests passed')
