#!/usr/bin/env bash
set -euo pipefail
: "${TARGET_PROFILE:?}" "${CENTRAL_ACCOUNT_ID:?}" "${INSTANCE_ROLE_NAMES:?}" "${CENTRAL_COORDINATOR_ROLE_ARN:?}" "${CENTRAL_SECRETS_KEY_ARN:?}"
REGION=${REGION:-ap-southeast-2}
cd "$(dirname "$0")"
python3 infra/generate.py
aws --profile "$TARGET_PROFILE" --region "$REGION" cloudformation deploy \
 --stack-name windows-admin-rotation-target --template-file infra/target.yaml \
 --capabilities CAPABILITY_NAMED_IAM \
 --parameter-overrides "CentralAccountId=$CENTRAL_ACCOUNT_ID" "CentralRegion=$REGION" "InstanceRoleNames=$INSTANCE_ROLE_NAMES" "CentralCoordinatorRoleArn=$CENTRAL_COORDINATOR_ROLE_ARN" "CentralSecretsKeyArn=$CENTRAL_SECRETS_KEY_ARN"
if aws --profile "$TARGET_PROFILE" --region "$REGION" ssm describe-document --name WindowsLocalAdminRotate >/dev/null 2>&1; then
  aws --profile "$TARGET_PROFILE" --region "$REGION" ssm update-document --name WindowsLocalAdminRotate --document-format JSON --content file://infra/ssm-document.json
  VERSION=$(aws --profile "$TARGET_PROFILE" --region "$REGION" ssm describe-document --name WindowsLocalAdminRotate --query 'Document.LatestVersion' --output text)
  aws --profile "$TARGET_PROFILE" --region "$REGION" ssm update-document-default-version --name WindowsLocalAdminRotate --document-version "$VERSION"
else
  aws --profile "$TARGET_PROFILE" --region "$REGION" ssm create-document --name WindowsLocalAdminRotate --document-type Command --document-format JSON --content file://infra/ssm-document.json
fi
