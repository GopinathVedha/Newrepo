# Windows Local Administrator Rotation — Multi-Account, Multiple EC2 IAM Roles (Pilot v2)

**Scope:** Existing local Windows built-in Administrator (SID `-500`) on tagged EC2 instances, approximately 200 across multiple AWS accounts. **Password length: 20 characters.** Central Secrets Manager in `ap-southeast-2`; quarterly schedule remains **dry-run**. No shared EC2 instance-role name is required.

> **Pilot/reference implementation. Do not enable an unattended production rollout without integration tests, concurrency locking, automated recovery/reconciliation, policy/security review, and a verified break-glass method.** Previous versions of this package used one EC2 IAM role per account; this version replaces that requirement.

## What changed in v2

- `target.yaml`: `InstanceRoleNames` is a **comma-separated list** of existing IAM role **names**, specific to each target account. CloudFormation attaches one read-only managed policy to *all* names in that list. Every target account can have a different list.
- `central.yaml`: removed `ExistingInstanceRoleName`; central key policy instead restricts `kms:Decrypt` to listed target **account IDs**, calls via **central Secrets Manager**, and rotation-secret KMS encryption context. An identity-policy allow and a per-secret resource-policy allow are also needed. This avoids massive key policies listing hundreds of server-role ARNs.
- Lambda: reads each instance's **actual IAM role ARN** from its EC2 instance profile via target `iam:GetInstanceProfile`. The central secret's resource policy grants the **actual role**, not a hardcoded name.
- `PASSWORD_LENGTH=20`, all four password character classes, strong random generator.
- Corrected SSM polling for repeated `IN_PROGRESS`, clears `AWSPENDING` after a successful promotion, avoids creating an initial `AWSCURRENT` credential before Windows has been changed, and adds per-item task-error reporting.

## Prerequisites

- Same target Region for this deployment (`ap-southeast-2`). Expand multi-Region support separately if needed.
- Administrative CloudFormation permissions in central and target accounts; existing S3 artifact bucket in central account.
- Windows SSM Agent online, existing EC2 role, local Administrator account active, AWS CLI v2 installed **on Windows** (this script requires it), IMDSv2 access, and network routes to SSM/Secrets Manager/KMS.
- Every test server has a validated independent break-glass recovery procedure, and its built-in Administrator is not controlled by Windows LAPS/other rotation software.
- Inventory test instances and obtain each **IAM role name**, not the *instance profile* name: `EC2 → Instances → Security → IAM Role`, then `IAM → Roles` to verify. Different servers can have different role names.
- If several EC2 instances use one role, that role can read any secret granted to it; per-instance IAM separation requires unique roles or a broker.

## Example for two target accounts

| Account | EC2 instances | Existing IAM role names (example) |
|---|---|---|
| 111111111111 | WIN-APP-01, WIN-DB-01, WIN-WEB-01 | AppWinRole, DatabaseWinRole, WebOpsRole |
| 222222222222 | WIN-API-01, WIN-BATCH-01 | EC2WindowsSSM, WindowsPatchRole |

There is **one central stack** and **one target stack in each account**, not one stack per server or per role. In target Account 111..., set `InstanceRoleNames=AppWinRole,DatabaseWinRole,WebOpsRole`. In Account 222..., set `InstanceRoleNames=EC2WindowsSSM,WindowsPatchRole`.

## Console-first deployment (new stacks)

### A. Central management account

1. Create or choose a **pre-existing** S3 artifact bucket in `ap-southeast-2` (for example `my-windows-rotation-artifacts-999999999999`). Do not confuse it with the audit report bucket created by CloudFormation.
2. In extracted package, ZIP `lambda/handler.py` so it is at the **root** of `coordinator.zip`. Example on Windows PowerShell in package folder: `Compress-Archive -Path .\lambda\handler.py -DestinationPath .\coordinator.zip -Force`.
3. Upload `coordinator.zip` to `s3://<artifact-bucket>/windows-rotation/coordinator.zip` and `infra/workflow.asl.json` to `s3://<artifact-bucket>/workflow.asl.json`. **Exact keys** matter.
4. `CloudFormation → Stacks → Create stack → With new resources → Upload a template file`: upload `infra/central.yaml`.
5. Stack name `windows-admin-rotation-central`. Enter: `Accounts=111111111111` (later add more comma-separated), `NotificationEmail=<email>`, `ReportBucketName=<globally-unique-new-bucket>`, `LambdaZipBucket=<artifact bucket>`, `LambdaZipKey=windows-rotation/coordinator.zip`; leave `RotationDays=90` unless client requirement differs.
6. On Review, acknowledge IAM creation (`CAPABILITY_IAM` equivalent) and submit. Wait for `CREATE_COMPLETE`.
7. CloudFormation **Outputs**: copy `CoordinatorRoleArn`, `KeyArn`, `WorkflowArn`; these are needed in target stack. Confirm SNS email subscription. Scheduler remains `dry_run=true`.

**Important:** For an existing central stack, upload the new Lambda ZIP and workflow JSON to the same S3 keys first, update the stack with the revised `central.yaml` (remove obsolete role-name parameter), and deploy a fresh Lambda code object/version. CloudFormation might not update the Lambda when S3 **key** stays the same: use a **new S3 object key** or run `Lambda → Upload from → Amazon S3` / `aws lambda update-function-code`. Update the stack's `LambdaZipKey` to the new unique key for a reliable change. Review CloudFormation change set before applying. **If a previous live rotation generated secrets, do not upgrade in place without reviewing existing secret version labels and resource policies.**

### B. Each target account (repeat, different role list per account)

1. Verify IAM role **names** attached to the 2–3 pilot EC2 Windows instances. Include every distinct role, e.g. `AppWinRole,DatabaseWinRole,WebOpsRole`.
2. `CloudFormation → Stacks → Create stack → With new resources → Upload`: select `infra/target.yaml`.
3. Stack name `windows-admin-rotation-target`.
4. Parameters:
   - `CentralAccountId`: `999999999999` (example central ID)
   - `CentralRegion`: `ap-southeast-2`
   - `CentralCoordinatorRoleArn`: central stack Output `CoordinatorRoleArn`
   - `CentralSecretsKeyArn`: central stack Output `KeyArn`
   - `InstanceRoleNames`: **comma-separated existing IAM role names in this target account ONLY**
5. Acknowledge named IAM role creation (`CAPABILITY_NAMED_IAM` equivalent). Submit and wait for `CREATE_COMPLETE`.
6. In IAM → Roles, open **each** configured EC2 IAM role and confirm the new customer-managed read policy is attached. Do not grant `SecretsManagerFullAccess` or `SecretsManagerReadWrite` to Windows instances.
7. `Systems Manager → Documents → Create document` (Command/Session type). Paste `infra/ssm-document.json` as JSON, name it `WindowsLocalAdminRotate`, and save. The document is **not** provisioned by target CloudFormation.
8. Confirm `WindowsRotationExecutionRole` trusts **only** the central `CoordinatorRoleArn` and has the SSM + EC2 describe + `iam:GetInstanceProfile` permissions from the target stack.

### C. Pilot safely

1. Add tag `PasswordRotation=enabled` only to 2–3 **non-production** Windows instances. All other instances remain out of scope.
2. In **central account → Step Functions → State machines**, open stack state machine → **Start execution** with JSON:

```json
{"dry_run":true,"instance_ids":["i-0123456789abcdef0","i-0123456789abcdef1"]}
```

3. Check execution history, S3 CSV/JSON report, SNS summary. Dry-run should return `DRY_RUN_DUE` for eligible instances and must **not** change the password or stage a secret.
4. Only after pilot review/rollback plan and per-instance role-policy access checks, consider a **supervised** live one-server execution. Do **not** use this reference package as an unattended production scheduler without finishing the hardening described below.

## IAM permissions summary

| Principal | Secrets Manager | KMS |
|---|---|---|
| Each existing Windows EC2 IAM role listed in target stack | `GetSecretValue`, `DescribeSecret` on rotation secrets **in its target account and Region** | `Decrypt` on **central specific key ARN**, restricted via Secrets Manager |
| Cross-account target execution role | No direct secret/KMS permission needed | None required |
| Central coordinator Lambda execution role | `CreateSecret`, `DescribeSecret`, `GetSecretValue`, `PutSecretValue`, `PutResourcePolicy`, `UpdateSecretVersionStage` for `windows/local-admin/*` | `GenerateDataKey`, `Decrypt`, `DescribeKey` on central key |

Three independent authorizations are involved when Windows reads a cross-account secret: **instance IAM role policy + exact central secret resource policy + central KMS key policy**. The key policy permits only specified target account IDs and requests via Secrets Manager with the correct encryption context. AWS cross-account KMS/Secrets Manager access must be verified in a pilot environment.

## Limitations and next production steps

- This package is a **supervised pilot**, not a guarantee of production-ready credential rotation. Add: a per-instance concurrency lock, durable state transitions, automatic reconciliation for ambiguous success, better automatic retry/backoff, and stronger workflow failure handling.
- The Windows verification uses `LogonUser` interactive authentication. Test domain/Windows interactive-logon policies; an otherwise valid new password can fail verification if local logon is denied.
- During a new secret's first version, AWS Secrets Manager may add `AWSCURRENT` automatically. This coordinator attempts to remove it before invoking SSM and fails closed if the label remains. Check version labels carefully before any live test.
- A server or administrator with access to an IAM role can read all rotation secrets granting that role access. Different role names are supported but **sharing a role does not provide per-server isolation**.
- Existing local Administrator password shown by EC2 Get Windows Password (key pair) will not update after custom rotation. Use central Secrets Manager for the new password.
- Keep report bucket and secret reveal permissions restricted; never add passwords to logs or email. Cross-account target roles require authorization to retrieve central secrets over the network.
- If `AWSPENDING` exists or an SSM invocation has ambiguous status, **do not retry blindly**: follow the documented break-glass and reconciliation process before further rotations.
- Test and approve IAM/KMS policy changes with your security team.

## Source files

`infra/central.yaml`: central resources and KMS account scoping  
`infra/target.yaml`: one target-account execution role + managed secret-read policy for **multiple existing IAM roles**  
`lambda/handler.py`: real EC2 instance-role resolution, secret staging, SSM dispatch, audit  
`infra/workflow.asl.json`: Step Functions workflow  
`infra/ssm-document.json`: generated Windows SSM command document  
`ssm/rotate.ps1`: password change and local credential check  
`deploy.sh`, `deploy-target.sh`: optional AWS CLI deployment scripts  
`docs/WORKFLOW.md`: Mermaid architecture  
`tests/test_core.py`: static checks
