#!/usr/bin/env bash
set -euo pipefail
: "${CENTRAL_PROFILE:?}" "${CENTRAL_ACCOUNT_ID:?}" "${TARGET_ACCOUNT_IDS:?}" "${REPORT_BUCKET:?}" "${NOTIFICATION_EMAIL:?}" "${ARTIFACT_BUCKET:?}"
REGION=${REGION:-ap-southeast-2}
cd "$(dirname "$0")"
python3 infra/generate.py
(cd lambda && zip -q -j ../coordinator.zip handler.py)
aws --profile "$CENTRAL_PROFILE" --region "$REGION" s3 cp coordinator.zip "s3://${ARTIFACT_BUCKET}/windows-rotation/coordinator.zip"
aws --profile "$CENTRAL_PROFILE" --region "$REGION" s3 cp infra/workflow.asl.json "s3://${ARTIFACT_BUCKET}/workflow.asl.json"
aws --profile "$CENTRAL_PROFILE" --region "$REGION" cloudformation deploy \
 --stack-name windows-admin-rotation-central --template-file infra/central.yaml \
 --capabilities CAPABILITY_IAM \
 --parameter-overrides "Accounts=$TARGET_ACCOUNT_IDS" "NotificationEmail=$NOTIFICATION_EMAIL" \
 "ReportBucketName=$REPORT_BUCKET" \
 "LambdaZipBucket=$ARTIFACT_BUCKET" "LambdaZipKey=windows-rotation/coordinator.zip"
cat <<'EOF'
Central stack deployed. Confirm SNS email subscription; deploy target stack and SSM document to each target account.
Scheduled workflow input is dry_run=true and will remain so until deliberately changed.
EOF
