"""Generate Step Functions JSON and SSM document content."""
import json, pathlib
base=pathlib.Path(__file__).resolve().parent
ps=(base.parent/'ssm'/'rotate.ps1').read_text()
# CloudFormation deployment will provision this JSON via aws ssm create-document.
doc={"schemaVersion":"2.2","description":"Rotate local built-in Windows Administrator using staged central secret. No password in command parameters.",
 "parameters":{"SecretArn":{"type":"String","description":"Central secret ARN"},"Mode":{"type":"String","default":"apply","allowedValues":["apply","verify"]}},
 "mainSteps":[{"action":"aws:runPowerShellScript","name":"rotate", "inputs":{"runCommand":[
  "$ErrorActionPreference = 'Stop'", 
  "$script = @'",*ps.splitlines(),"'@", 
  "$f = Join-Path $env:TEMP ('win-rotate-' + [guid]::NewGuid().ToString() + '.ps1')", 
  "try { [IO.File]::WriteAllText($f,$script); & $f -SecretArn '{{ SecretArn }}' -Mode '{{ Mode }}'; if ($LASTEXITCODE -ne 0) { exit 1 } } finally { Remove-Item $f -ErrorAction SilentlyContinue }"
 ]}}]}
(base/'ssm-document.json').write_text(json.dumps(doc,indent=2))
invoke=lambda action,item,result: {'Type':'Task','Resource':'arn:aws:states:::lambda:invoke',
 'Parameters':{'FunctionName':'${LambdaArn}','Payload':{'action':action,'item.$':item}},
 'OutputPath':'$.Payload','Next':result,
 'Retry':[{'ErrorEquals':['Lambda.ServiceException','Lambda.AWSLambdaException','Lambda.SdkClientException'],'IntervalSeconds':2,'MaxAttempts':3,'BackoffRate':2}]}
# Map's iteration requires retaining mutable state, use native ResultPath and Payload selectors
states={
 'Prepare':{'Type':'Task','Resource':'arn:aws:states:::lambda:invoke',
            'Parameters':{'FunctionName':'${LambdaArn}','Payload':{'action':'prepare','item.$':'$'}},
            'OutputPath':'$.Payload','Next':'IfPrepared'},
 'IfPrepared':{'Type':'Choice','Choices':[{'Variable':'$.status','StringEquals':'PREPARED','Next':'Send'}], 'Default':'Done'},
 'Send':{'Type':'Task','Resource':'arn:aws:states:::lambda:invoke',
         'Parameters':{'FunctionName':'${LambdaArn}','Payload':{'action':'send','item.$':'$'}},
         'OutputPath':'$.Payload','Next':'IfSent'},
 'IfSent':{'Type':'Choice','Choices':[{'Variable':'$.status','StringEquals':'SENT','Next':'Wait'}], 'Default':'Done'},
 'Wait':{'Type':'Wait','Seconds':15,'Next':'Poll'},
 'Poll':{'Type':'Task','Resource':'arn:aws:states:::lambda:invoke',
         'Parameters':{'FunctionName':'${LambdaArn}','Payload':{'action':'poll','item.$':'$'}},
         'OutputPath':'$.Payload','Next':'PollStatus'},
 'PollStatus':{'Type':'Choice','Choices':[
     {'Variable':'$.status','StringEquals':'VERIFIED','Next':'Commit'},
     {'And':[{'Variable':'$.status','StringEquals':'IN_PROGRESS'},{'Variable':'$.poll_attempts','NumericLessThan':25}],'Next':'Wait'}], 'Default':'Done'},
 'Commit':{'Type':'Task','Resource':'arn:aws:states:::lambda:invoke',
         'Parameters':{'FunctionName':'${LambdaArn}','Payload':{'action':'commit','item.$':'$'}},
         'OutputPath':'$.Payload','Next':'Done'},
 'Done':{'Type':'Succeed'}}
# Failed per-item Lambda tasks are converted into a sanitized report row, not an aborted batch.
states['Failure'] = {'Type':'Task','Resource':'arn:aws:states:::lambda:invoke',
 'Parameters':{'FunctionName':'${LambdaArn}','Payload':{'action':'failure','item.$':'$'}},
 'OutputPath':'$.Payload','Next':'Done'}
for step in ('Prepare','Send','Poll','Commit'):
    states[step]['Catch'] = [{'ErrorEquals':['States.ALL'],'ResultPath':'$.error','Next':'Failure'}]
# Avoid unbounded poll by using Map item processor timeout (20 minutes)
flow={'Comment':'Central Windows local admin password rotation','StartAt':'Discover', 'TimeoutSeconds':14400,
 'States':{
  'Discover':{'Type':'Task','Resource':'arn:aws:states:::lambda:invoke',
     'Parameters':{'FunctionName':'${LambdaArn}','Payload':{'action':'discover','dry_run.$':'$.dry_run','instance_ids.$':'$.instance_ids'}},
     'ResultSelector':{'items.$':'$.Payload.items','run_id.$':'$.Payload.run_id','dry_run.$':'$.Payload.dry_run'},
     'Next':'Process'},
  'Process':{'Type':'Map','ItemsPath':'$.items','MaxConcurrency':10,
             'ItemProcessor':{'ProcessorConfig':{'Mode':'INLINE'},'StartAt':'Prepare','States':states},
             'ResultPath':'$.results','Next':'Report'},
  'Report':{'Type':'Task','Resource':'arn:aws:states:::lambda:invoke',
          'Parameters':{'FunctionName':'${LambdaArn}','Payload':{'action':'report','results.$':'$.results','run_id.$':'$.run_id'}},
          'OutputPath':'$.Payload','End':True}}}
# Missing keys handled by workflow input defaults supplied by deployment command.
(base/'workflow.asl.json').write_text(json.dumps(flow,indent=2))
print('Generated workflow.asl.json and ssm-document.json')
