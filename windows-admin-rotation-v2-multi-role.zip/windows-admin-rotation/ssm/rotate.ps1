param([Parameter(Mandatory=$true)][string]$SecretArn,
      [ValidateSet('apply','verify')][string]$Mode='apply')
$ErrorActionPreference='Stop'
# Run Command executes as NT AUTHORITY\SYSTEM. Requires AWS CLI v2 on PATH or standard location.
$aws = (Get-Command aws.exe -ErrorAction SilentlyContinue).Source
if (-not $aws) { $aws = 'C:\Program Files\Amazon\AWSCLIV2\aws.exe' }
if (-not (Test-Path $aws)) { throw 'AWSCLI_NOT_INSTALLED' }
# Only the pending secret for this specific instance should be permitted by IAM.
$raw = & $aws secretsmanager get-secret-value --region 'ap-southeast-2' --secret-id $SecretArn --version-stage AWSPENDING --query SecretString --output text 2>$null
if ($LASTEXITCODE -ne 0 -or -not $raw) { throw 'SECRET_READ_FAILED' }
$secret = $raw | ConvertFrom-Json
$raw=$null
# Bind the secret to the actual EC2 instance (IMDSv2). Block mistaken secret/host targeting.
$token = Invoke-RestMethod -Method PUT -Uri 'http://169.254.169.254/latest/api/token' -Headers @{'X-aws-ec2-metadata-token-ttl-seconds'='60'} -TimeoutSec 3
$actualId = Invoke-RestMethod -Method GET -Uri 'http://169.254.169.254/latest/meta-data/instance-id' -Headers @{'X-aws-ec2-metadata-token'=$token} -TimeoutSec 3
if ($secret.instance_id -ne $actualId) { throw 'INSTANCE_ID_MISMATCH' }
# Resolve the BUILTIN local Administrator independent of its displayed name.
$account = Get-CimInstance Win32_UserAccount -Filter 'LocalAccount=True' | Where-Object { $_.SID -match '-500$' } | Select-Object -First 1
if (-not $account) { throw 'BUILTIN_ADMIN_NOT_FOUND' }
if ($account.Disabled) { throw 'BUILTIN_ADMIN_DISABLED' }
$name=$account.Name
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class LocalCredentialCheck {
  [DllImport("advapi32.dll", SetLastError=true, CharSet=CharSet.Unicode)]
  public static extern bool LogonUser(string user, string domain, string password, int type, int provider, out IntPtr token);
  [DllImport("kernel32.dll")] public static extern bool CloseHandle(IntPtr token);
}
'@
function Test-LocalPassword([string]$User,[string]$Password) {
  $token=[IntPtr]::Zero
  # LOGON32_LOGON_INTERACTIVE = 2; may fail if policy denies local interactive logon.
  $ok=[LocalCredentialCheck]::LogonUser($User,$env:COMPUTERNAME,$Password,2,0,[ref]$token)
  if ($token -ne [IntPtr]::Zero) { [void][LocalCredentialCheck]::CloseHandle($token) }
  return $ok
}
try {
  if ($Mode -eq 'verify') {
    if (Test-LocalPassword $name $secret.password) { Write-Output 'ROTATION_VERIFIED'; exit 0 }
    throw 'PENDING_PASSWORD_NOT_VERIFIED'
  }
  # Idempotent on retry after a command timeout: never unnecessarily change again.
  if (Test-LocalPassword $name $secret.password) { Write-Output 'ROTATION_VERIFIED'; exit 0 }
  $user = [ADSI]("WinNT://{0}/{1},user" -f $env:COMPUTERNAME,$name)
  $user.SetPassword([string]$secret.password)
  $user.SetInfo()
  if (-not (Test-LocalPassword $name $secret.password)) { throw 'PASSWORD_VERIFICATION_FAILED' }
  Write-Output 'ROTATION_VERIFIED'
} finally { $secret=$null; $user=$null }
