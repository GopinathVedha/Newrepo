"""Central multi-account Windows local Administrator rotation orchestrator.
Secrets never enter task results, command parameters, logs or reports.
"""
import boto3
import botocore
import csv
import datetime as dt
import io
import json
import os
import secrets
import string
import time
import uuid

REGION = os.getenv('AWS_REGION', 'ap-southeast-2')
CENTRAL = os.environ['CENTRAL_ACCOUNT_ID']
ACCOUNTS = [x.strip() for x in os.environ['TARGET_ACCOUNT_IDS'].split(',') if x.strip()]
ROLE = os.getenv('TARGET_ROLE_NAME', 'WindowsRotationExecutionRole')
DOC = os.getenv('SSM_DOCUMENT_NAME', 'WindowsLocalAdminRotate')
PREFIX = os.getenv('SECRET_PREFIX', 'windows/local-admin').strip('/')
BUCKET = os.environ['REPORT_BUCKET']
EMAIL = os.getenv('NOTIFICATION_EMAIL', '')
DRY_DEFAULT = os.getenv('DRY_RUN', 'true').lower() == 'true'
DAYS = int(os.getenv('ROTATION_DAYS', '90'))
LEN = int(os.getenv('PASSWORD_LENGTH', '20'))
if LEN < 12 or LEN > 128:
    raise ValueError('PASSWORD_LENGTH must be between 12 and 128')
KMS = os.environ['SECRETS_KMS_KEY_ARN']
sm = boto3.client('secretsmanager', region_name=REGION)
s3 = boto3.client('s3', region_name=REGION)
sts = boto3.client('sts', region_name=REGION)
sns = boto3.client('sns', region_name=REGION)


def assume(account, service):
    c = sts.assume_role(RoleArn=f'arn:aws:iam::{account}:role/{ROLE}', RoleSessionName='WindowsRotation')
    k = c['Credentials']
    return boto3.client(service, region_name=REGION, aws_access_key_id=k['AccessKeyId'],
                        aws_secret_access_key=k['SecretAccessKey'], aws_session_token=k['SessionToken'])


def sname(account, instance):
    return f'{PREFIX}/{account}/{REGION}/{instance}'


def get_secret(name, stage='AWSCURRENT'):
    try:
        return json.loads(sm.get_secret_value(SecretId=name, VersionStage=stage)['SecretString'])
    except sm.exceptions.ResourceNotFoundException:
        return None
    except botocore.exceptions.ClientError as ex:
        if ex.response['Error']['Code'] in ('ResourceNotFoundException', 'InvalidRequestException'):
            return None
        raise


def create_password():
    # Alphanumeric plus Windows-compatible symbols. Ensure all four classes.
    alphabet = string.ascii_letters + string.digits + '!@#%_-+=?'
    p = [secrets.choice(x) for x in (string.ascii_lowercase, string.ascii_uppercase, string.digits, '!@#%_-+=?')]
    p += [secrets.choice(alphabet) for _ in range(max(0, LEN-4))]
    secrets.SystemRandom().shuffle(p)
    return ''.join(p)


def discover(event):
    raw_dry = event.get('dry_run', DRY_DEFAULT)
    dry = raw_dry if isinstance(raw_dry, bool) else str(raw_dry).lower() == 'true'
    include = set(event.get('instance_ids') or [])
    rows = []
    for account in ACCOUNTS:
        try:
            ec2, ssm, iam = assume(account, 'ec2'), assume(account, 'ssm'), assume(account, 'iam')
            managed = set()
            for page in ssm.get_paginator('describe_instance_information').paginate():
                managed.update(i['InstanceId'] for i in page['InstanceInformationList'] if i.get('PingStatus') == 'Online')
            role_cache = {}
            for page in ec2.get_paginator('describe_instances').paginate(Filters=[
                {'Name':'platform', 'Values':['windows']}, {'Name':'instance-state-name','Values':['running']} ]):
                for reservation in page['Reservations']:
                    for instance in reservation['Instances']:
                        iid = instance['InstanceId']
                        if include and iid not in include:
                            continue
                        tags = {t['Key']:t['Value'] for t in instance.get('Tags', [])}
                        if tags.get('PasswordRotation', '').lower() != 'enabled':
                            continue
                        if tags.get('PasswordRotationExclude', '').lower() == 'true':
                            continue
                        row = {'account':account, 'instance':iid, 'name':tags.get('Name',''),
                               'ssm_online':iid in managed, 'dry_run':dry}
                        try:
                            profile_arn = instance.get('IamInstanceProfile', {}).get('Arn', '')
                            if not profile_arn:
                                raise ValueError('EC2_INSTANCE_PROFILE_MISSING')
                            profile_name = profile_arn.rsplit('/', 1)[-1]
                            if profile_name not in role_cache:
                                profiles = iam.get_instance_profile(InstanceProfileName=profile_name)['InstanceProfile']
                                roles = profiles.get('Roles', [])
                                if len(roles) != 1:
                                    raise ValueError('EXPECTED_ONE_INSTANCE_ROLE')
                                role_cache[profile_name] = roles[0]['Arn']
                            row['instance_role_arn'] = role_cache[profile_name]
                        except Exception as ex:
                            row['role_error'] = type(ex).__name__
                        rows.append(row)
        except Exception as ex:
            rows.append({'account':account, 'instance':'', 'name':'', 'ssm_online':False,
                         'dry_run':dry, 'discovery_error':type(ex).__name__})
    return {'items':rows, 'dry_run':dry, 'run_id':event.get('run_id', str(uuid.uuid4()))}


def _resource_policy(secret_arn, instance_role_arn):
    role = instance_role_arn
    sm.put_resource_policy(SecretId=secret_arn, BlockPublicPolicy=True, ResourcePolicy=json.dumps({
        'Version':'2012-10-17','Statement':[{'Effect':'Allow','Principal':{'AWS':role},
        'Action':['secretsmanager:GetSecretValue','secretsmanager:DescribeSecret'], 'Resource':'*'}]}))


def _prepare(row):
    result = dict(row)
    result['status'] = 'SKIPPED'
    if not row.get('instance'):
        result['status']='DISCOVERY_ERROR'; return result
    if not row['ssm_online']:
        result['status']='OFFLINE'; return result
    if row.get('role_error'):
        result['status']='ROLE_DISCOVERY_ERROR'; result['reason']=row['role_error']; return result
    name = sname(row['account'],row['instance'])
    result['secret_name'] = name
    pending = get_secret(name,'AWSPENDING')
    if pending:
        result['status']='PENDING_RECONCILIATION'; return result
    current = get_secret(name)
    if current and current.get('rotated_at'):
        last = dt.datetime.fromisoformat(current['rotated_at'].replace('Z','+00:00'))
        if (dt.datetime.now(dt.timezone.utc)-last).days < DAYS:
            result['status']='NOT_DUE'; return result
    if row['dry_run']:
        result['status']='DRY_RUN_DUE'; return result
    token = str(uuid.uuid4())
    val = {'username':'Administrator (SID -500)', 'password':create_password(),
           'rotation_token':token, 'instance_id':row['instance'], 'account_id':row['account'],
           'created_at':dt.datetime.now(dt.timezone.utc).isoformat(),
           'rotated_at':dt.datetime.now(dt.timezone.utc).isoformat()}
    try:
        if not current:
            # Never publish an unapplied password as AWSCURRENT, even briefly.
            try:
                arn = sm.describe_secret(SecretId=name)['ARN']
            except sm.exceptions.ResourceNotFoundException:
                arn = sm.create_secret(Name=name, KmsKeyId=KMS)['ARN']
        else:
            arn = sm.describe_secret(SecretId=name)['ARN']
        sm.put_secret_value(SecretId=name, ClientRequestToken=token,
                            SecretString=json.dumps(val), VersionStages=['AWSPENDING'])
        if not current:
            # The first PutSecretValue may automatically add AWSCURRENT even with
            # an explicit AWSPENDING stage. Do not expose an unapplied credential as current.
            versions = sm.describe_secret(SecretId=name).get('VersionIdsToStages', {})
            if 'AWSCURRENT' in versions.get(token, []):
                sm.update_secret_version_stage(SecretId=name, VersionStage='AWSCURRENT',
                                               RemoveFromVersionId=token)
            versions = sm.describe_secret(SecretId=name).get('VersionIdsToStages', {})
            if 'AWSCURRENT' in versions.get(token, []):
                raise RuntimeError('UNAPPLIED_PASSWORD_MARKED_CURRENT')
        _resource_policy(arn,row['instance_role_arn'])
        result.update(status='PREPARED', token=token, secret_arn=arn)
    except Exception:
        # Persisted pending versions are intentionally not deleted on failure.
        result['status']='PREPARE_ERROR'; result['reason']='Review pending secret state and permissions'
    return result


def _send(row, mode='apply'):
    result = dict(row)
    if row.get('status') != 'PREPARED': return result
    client = assume(row['account'], 'ssm')
    try:
        cmd = client.send_command(InstanceIds=[row['instance']], DocumentName=DOC,
                                  Parameters={'SecretArn':[row['secret_arn']], 'Mode':[mode]},
                                  TimeoutSeconds=240, MaxConcurrency='1', MaxErrors='0',
                                  Comment='Local administrator rotation: no secret values in parameters',
                                  CloudWatchOutputConfig={'CloudWatchOutputEnabled':False})
        result['command_id'] = cmd['Command']['CommandId']; result['status']='SENT'
    except Exception:
        result['status']='SEND_ERROR'
    return result


def _poll(row):
    result = dict(row)
    if row.get('status') not in ('SENT', 'IN_PROGRESS'): return result
    result['poll_attempts'] = int(row.get('poll_attempts',0)) + 1
    if result['poll_attempts'] > 24:
        result['status']='NEEDS_RECONCILIATION'; result['reason']='Polling deadline exceeded'; return result
    try:
        response = assume(row['account'],'ssm').get_command_invocation(
            CommandId=row['command_id'],InstanceId=row['instance'])
        state = response['Status']
        if state == 'Success' and 'ROTATION_VERIFIED' in response.get('StandardOutputContent',''):
            result['status']='VERIFIED'
        elif state in ('Pending','InProgress','Delayed'):
            result['status']='IN_PROGRESS'
        else:
            result['status']='NEEDS_RECONCILIATION'
            result['reason']=state
    except Exception:
        result['status']='IN_PROGRESS'  # eventual consistency; bounded by Step Functions
    return result


def _commit(row):
    result = {k:v for k,v in row.items() if k!='token'}
    if row.get('status') != 'VERIFIED': return result
    try:
        sm.update_secret_version_stage(SecretId=row['secret_arn'], VersionStage='AWSCURRENT',
                                       MoveToVersionId=row['token'])
        # AWSPENDING is not removed automatically by promotion; clear it after success.
        sm.update_secret_version_stage(SecretId=row['secret_arn'], VersionStage='AWSPENDING',
                                       RemoveFromVersionId=row['token'])
        # Record rotation time in S3 report, rather than changing the secret after promotion.
        result['status']='SUCCESS'; result['rotated_at']=dt.datetime.now(dt.timezone.utc).isoformat()
    except Exception:
        result['status']='COMMIT_ERROR' # pending version remains accessible
    return result


def _report(event):
    rows = event['results']; run = event['run_id']
    safe = [{k:v for k,v in r.items() if k not in ('token','password')} for r in rows]
    key=f'windows-rotation/{dt.datetime.now(dt.timezone.utc):%Y/%m/%d}/{run}.json'
    s3.put_object(Bucket=BUCKET,Key=key,Body=json.dumps(safe,indent=2,default=str).encode(),
                  ServerSideEncryption='AES256',ContentType='application/json')
    csvkey=key[:-5]+'.csv'
    buf=io.StringIO()
    cols=['account','instance','name','instance_role_arn','status','ssm_online','dry_run','secret_name','command_id','reason','rotated_at']
    writer=csv.DictWriter(buf,fieldnames=cols,extrasaction='ignore');writer.writeheader();writer.writerows(safe)
    s3.put_object(Bucket=BUCKET,Key=csvkey,Body=buf.getvalue().encode(),ServerSideEncryption='AES256',ContentType='text/csv')
    statuses={}
    for r in safe:statuses[r.get('status','UNKNOWN')]=statuses.get(r.get('status','UNKNOWN'),0)+1
    body=f'Windows rotation {run}\nRegion: {REGION}\nResults: {json.dumps(statuses)}\nReport: s3://{BUCKET}/{csvkey}\nNo passwords included.'
    if os.getenv('SNS_TOPIC_ARN'):sns.publish(TopicArn=os.environ['SNS_TOPIC_ARN'],Subject='Windows Local Admin Rotation Report',Message=body)
    return {'report':f's3://{BUCKET}/{csvkey}','counts':statuses,'total':len(safe)}


def _failure(row):
    # A Step Functions Task-level error must still produce a sanitized per-server record.
    return {k:v for k,v in row.items() if k not in ('token', 'error')} | {
        'status':'WORKFLOW_ERROR', 'reason':'See Step Functions execution history'
    }


def handler(event, context):
    action=event.get('action')
    if action=='discover':return discover(event)
    if action=='prepare':return _prepare(event['item'])
    if action=='send':return _send(event['item'])
    if action=='poll':return _poll(event['item'])
    if action=='commit':return _commit(event['item'])
    if action=='report':return _report(event)
    if action=='failure':return _failure(event['item'])
    raise ValueError('Unsupported action')
