# Multi-account Windows local Administrator password rotation (v2)

```mermaid
flowchart TB
  S[EventBridge Scheduler - quarterly dry-run default] --> W[Central Step Functions]
  W --> L[Central Python Lambda]
  L --> A[Cross-account STS AssumeRole]
  A --> T[Target account A - WindowsRotationExecutionRole]
  A --> U[Target account B - WindowsRotationExecutionRole]
  T --> I[EC2 DescribeInstances and IAM GetInstanceProfile]
  U --> I
  I --> R[Resolve each instance's actual EC2 IAM role ARN]
  R --> D{Tagged, online, rotation due?}
  D -- No --> O[Skip/report]
  D -- Yes --> DR{Dry-run?}
  DR -- Yes --> O
  DR -- No --> P[Generate unique 20-character password; stage AWSPENDING]
  P --> Q[Grant exact instance role in central secret resource policy]
  Q --> K[Target SSM command]
  K --> J[Windows EC2 role reads its own pending secret via central Secrets Manager and KMS]
  J --> V[Apply SID-500 local Administrator password and verify locally]
  V -- Verified --> C[Promote AWSCURRENT; clear AWSPENDING]
  V -- Failed / uncertain --> X[Retain staged secret; reconciliation required]
  C --> Z[Central S3 CSV/JSON + SNS summary]
  X --> Z
  O --> Z
```

## Permission design

The target-account CloudFormation stack accepts `InstanceRoleNames` as a different comma-separated list in *each* account. It attaches a **read-only managed policy** to all specified existing roles. No common role name is required across machines/accounts. The central coordinator resolves each instance's real IAM role via `iam:GetInstanceProfile` and writes an exact-role central secret resource policy. The central KMS key uses target-account ID, Secrets Manager service and secret ARN encryption-context restrictions instead of listing 200 roles.

**Important:** This is a pilot architecture. Add concurrency control, verified reconciliation, and operational recovery before unattended rotation.
